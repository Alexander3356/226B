package ch.samt.enumerators;

public enum Sector {

    CURVA,
    TRIBUNA

}
