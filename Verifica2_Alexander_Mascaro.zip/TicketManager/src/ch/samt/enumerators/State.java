package ch.samt.enumerators;

public enum State {
    DISPONIBILE,
    VENDUTO

}
