package ch.samt.talentshow.enumerator;

public enum Categoria {
    SINGER,
    DANCER,
    MAGICIAN
}
