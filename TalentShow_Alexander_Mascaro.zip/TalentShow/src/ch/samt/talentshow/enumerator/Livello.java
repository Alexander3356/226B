package ch.samt.talentshow.enumerator;

public enum Livello {

        BEGINNER,
        INTERMEDIATE,
        PROFESSIONAL


}
